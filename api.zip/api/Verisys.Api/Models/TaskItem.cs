namespace Verisys.Api.Models;

public record TaskItem(int Id, string Title, string Status);
